export class Property{
   
         id !:number;
         pTitle:string = '';
         pPrice:string = '' ;
         pLocation:string = '';
         pDetails:string = '';
 
    }